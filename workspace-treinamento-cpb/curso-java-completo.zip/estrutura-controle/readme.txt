Programa: 			estrutura-controle
Descricao: 			Demonstra a utilizacao do if e switch
Caracteristicas:
  
  1) Demonstra o uso do if e switch
  2) Execucao em linha de comando:
  
  		java -jar estrutura-controle-0.0.1-SNAPSHOT.jar