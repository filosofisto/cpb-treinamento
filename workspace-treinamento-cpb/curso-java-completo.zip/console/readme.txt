Programa: 			console
Descricao: 			Demonstra a leitura do console
Caracteristicas:
  
  1) Demonstra o uso da classe Console, Scanner e System.in
  2) Execucao em linha de comando:
  
  		java -jar console-0.0.1-SNAPSHOT.jar