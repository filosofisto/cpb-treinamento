Programa: 			lista-01-exercicio-16
Descricao: 			Resolução Lista 01 Exercício 16
