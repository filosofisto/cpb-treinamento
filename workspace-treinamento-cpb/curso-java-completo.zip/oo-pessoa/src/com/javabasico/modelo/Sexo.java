package com.javabasico.modelo;

public enum Sexo {

	MASCULINO, FEMININO;
}
