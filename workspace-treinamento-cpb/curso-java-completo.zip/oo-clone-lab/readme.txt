Programa: 			oo-clone-lab
Descricao: 			Resolucao laboratorio oo-clone
Caracteristicas:
  
  1) Clonagem de objetos com array
  2) Execucao em linha de comando:
  
  		java -jar oo-clone-lab-0.0.1-SNAPSHOT.jar