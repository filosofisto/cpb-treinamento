Programa: 			exception-3
Descricao: 			Criando excecos especificas
Caracteristicas:
  
  1) Demonstra a criacao de excecoes especificas (tipos)
  2) Execucao em linha de comando:
  
  		java -jar exception-3-0.0.1-SNAPSHOT.jar