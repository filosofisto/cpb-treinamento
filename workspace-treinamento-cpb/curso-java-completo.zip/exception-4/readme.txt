Programa: 			exception-4
Descricao: 			Tratamento de várias exceções
Caracteristicas:
  
  1) Demonstra tratamento de várias exceções
  2) Execucao em linha de comando:
  
  		java -jar exception-4-0.0.1-SNAPSHOT.jar