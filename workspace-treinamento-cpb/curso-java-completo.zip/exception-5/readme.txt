Programa: 			exception-5
Descricao: 			MultiCatch
Caracteristicas:
  
  1) Demonstra novo recurso de multicatch da versão 1.7
  2) Execucao em linha de comando:
  
  		java -jar exception-5-0.0.1-SNAPSHOT.jar