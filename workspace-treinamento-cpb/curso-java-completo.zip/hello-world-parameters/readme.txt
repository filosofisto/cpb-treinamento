Programa: 			hello-world-parameters
Descricao: 			Evolucao do hello-world, utilizando parametros na linha de comando
Caracteristicas:
  
  1) Demonstra o uso de parametros na linha de comando
  2) Array
  3) Execucao em linha de comando:
  
  		java -jar hello-world-parameters-0.0.1-SNAPSHOT.jar