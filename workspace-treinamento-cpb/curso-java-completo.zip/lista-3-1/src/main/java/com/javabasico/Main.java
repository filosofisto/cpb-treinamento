package com.javabasico;

public class Main {

	public static void main(String[] args) {
		Ponto p1 = new Ponto();
		Ponto p2 = new Ponto();
		Ponto p3 = new Ponto();
		
		//Ponto.ORIGEM = new Ponto(1,1);
		//Ponto.ORIGEM.setX(10);
		
		System.out.println(Ponto.getCount());
	}
}
