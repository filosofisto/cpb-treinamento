package com.javabasico;

public class Funcionario extends Pessoa {

}
