Programa: 			oo-2
Descricao: 			Object (equals e toString)
Caracteristicas:
  
  1) Demonstra uso do equals e toString
  2) Execucao em linha de comando:
  
  		java -jar oo-2-0.0.1-SNAPSHOT.jar