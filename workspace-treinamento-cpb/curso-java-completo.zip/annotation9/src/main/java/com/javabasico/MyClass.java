package com.javabasico;

import static java.lang.System.out;

public class MyClass {

	@Deprecated
	public void oldMethod() {
		out.println("Existe outro m�todo melhor");
	}
}
