package com.javabasico;

@Deprecated
public class VeryOldClass {

	public void m1() {
		
	}
	
	public void m2() {
		
	}
}
