Programa: 			exception-2
Descricao: 			Lança (throw) excecao em uma situação de erro
Caracteristicas:
  
  1) Demonstra o lançamento de exceções em situações de erro
  2) Execucao em linha de comando:
  
  		java -jar exception-2-0.0.1-SNAPSHOT.jar