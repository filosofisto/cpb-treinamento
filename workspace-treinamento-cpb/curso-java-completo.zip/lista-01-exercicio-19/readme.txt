Programa: 			lista-01-exercicio-19
Descricao: 			Resolução Lista 01 Exercício 19
