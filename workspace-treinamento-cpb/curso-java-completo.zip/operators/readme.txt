Programa: 			operators
Descricao: 			Demonstra a utilizacao dos principais operadores da linguagem
Caracteristicas:
  
  1) Demonstra o uso dos principais operadores
  2) Execucao em linha de comando:
  
  		java -jar operators-0.0.1-SNAPSHOT.jar