package com.javabasico.ageofempire.geo;

public class Mapa {

	public final static int MAX_X = 800;
	public final static int MAX_Y = 600;
}
