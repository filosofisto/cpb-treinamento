package com.javabasico.ageofempire.artefatos;

public class Lanca extends ArmaPadrao {

	@Override
	public int potencia() {
		return 30;
	}

	@Override
	public int alcance() {
		return 20;
	}

}
