package com.javabasico.ageofempire.artefatos;


public class Espada extends ArmaPadrao {

	@Override
	public int potencia() {
		return 10;
	}

	@Override
	public int alcance() {
		return 1;
	}
}
