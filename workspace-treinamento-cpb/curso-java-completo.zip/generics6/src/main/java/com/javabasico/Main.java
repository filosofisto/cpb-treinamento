package com.javabasico;


/**
 * Obtendo tipo parametrizado
 * 
 * @author eduardo
 *
 */
public class Main {

	public static void main(String[] args) {
		ListaEncadeadaSubClass list =
			new ListaEncadeadaSubClass();
		System.out.println(list.getParentItemClass());
	}
	
	
}