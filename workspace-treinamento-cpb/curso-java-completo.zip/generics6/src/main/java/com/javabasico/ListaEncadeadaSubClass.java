package com.javabasico;

public class ListaEncadeadaSubClass extends ListaEncadeada<Integer> {

}
