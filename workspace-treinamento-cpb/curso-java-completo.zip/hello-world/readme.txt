Programa: 			hello-world
Descricao: 			Primeiro programa em Java
Caracteristicas:
  
  1) Demonstra o uso do metodo main
  2) Demonstra o uso do Maven
  3) Conceito de package (namespace)
  4) Classe 
  5) Metodo static
  3) Execucao em linha de comando:
  
  		java -jar hello-world-0.0.1-SNAPSHOT.jar