package com.javabasico;

public class Main {

	/**
	 * Metodo principal acionado pela JVM.
	 * 
	 * @param args Lista de argumentos no console
	 */
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
}
