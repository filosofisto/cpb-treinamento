package com.javabasico;


public class Main {

	public static void main(String[] args) {
		Gerenciador gerenciador = new Gerenciador();
		gerenciador.executar();
	}
}
