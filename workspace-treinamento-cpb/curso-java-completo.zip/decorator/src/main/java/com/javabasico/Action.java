package com.javabasico;

public interface Action {

	void action();
}
