Programa: 			lista-01-exercicio-01
Descricao: 			Resolução Lista 01 Exercício 01
