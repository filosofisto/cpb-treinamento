package com.javabasico;

public interface Operation {

	String getDescricao();
	void execute();
	
}
