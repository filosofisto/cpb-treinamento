package com.javabasico;

public class CrazyFormatter implements Formatter {

}
