package com.javabasico;

@PrettyPrinter(value=CrazyFormatter.class)
public class MyCrazyClass {

}
