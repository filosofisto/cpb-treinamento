package com.javabasico;

public interface Formatter {

}
