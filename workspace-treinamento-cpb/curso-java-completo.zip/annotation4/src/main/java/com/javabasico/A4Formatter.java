package com.javabasico;

public class A4Formatter implements Formatter {

}
