package com.javabasico;

@PrettyPrinter(value=A4Formatter.class)
public class MyClass {

}
