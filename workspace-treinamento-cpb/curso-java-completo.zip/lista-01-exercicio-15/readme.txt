Programa: 			lista-01-exercicio-17
Descricao: 			Resolução Lista 01 Exercício 17
