package com.javabasico;

public class Quadrado extends Retangulo {

	public Quadrado(double lado) {
		super(lado, lado);
	}
}
