package com.javabasico;

public interface Conexao {

	void abrirConexao();
	
	void fecharConexao();
}
