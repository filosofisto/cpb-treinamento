package com.javabasico;

public interface Transformer {

	String transformarLinha(String linha);
}
