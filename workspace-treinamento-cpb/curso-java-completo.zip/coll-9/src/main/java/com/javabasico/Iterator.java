package com.javabasico;

public interface Iterator {

	boolean hasNext();
	
	Object next();
}
