package com.javabasico;

public interface Produto {

	Double preco();
}
