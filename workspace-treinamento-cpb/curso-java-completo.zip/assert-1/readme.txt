Programa: 			assert-1
Descricao: 			Assertions
Caracteristicas:
  
  1) Demonstra utilização de assertion
  2) Execucao em linha de comando:
  
  		Habilitando Asserts:
  		
  		java -ea -jar assert-1-0.0.1-SNAPSHOT.jar
  		
  		ou com Asserts desabilitados (default):
  		
  		java -jar assert-1-0.0.1-SNAPSHOT.jar 