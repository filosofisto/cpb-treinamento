Programa: 			exception-1
Descricao: 			Demonstra situação de erro
Caracteristicas:
  
  1) Demonstra situação de erro e tratamento padrão da JVM
  2) Execucao em linha de comando:
  
  		java -jar exception-1-0.0.1-SNAPSHOT.jar