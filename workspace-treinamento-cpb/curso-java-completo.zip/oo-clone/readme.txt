Programa: 			oo-clone
Descricao: 			Demonstra o processo de clonagem de objetos
Caracteristicas:
  
  1) Demonstra interface Cloneable, metodo clone, e clonagem de objetos complexos (grafo de objetos)
  2) Execucao em linha de comando:
  
  		java -jar oo-clone-0.0.1-SNAPSHOT.jar