package com.javabasico;

@Author(value=@Name(first="Helena", last="Blavatsky"))
@Reviewer(value=@Name(first="Annie", last="Besant"))
public class MyClass {

}
