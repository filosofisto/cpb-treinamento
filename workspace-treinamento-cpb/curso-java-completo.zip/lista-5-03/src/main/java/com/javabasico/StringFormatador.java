package com.javabasico;

public class StringFormatador implements Formatador<String>{

	@Override
	public String format(String objeto) {
		return objeto;
	}
}
