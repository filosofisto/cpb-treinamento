package com.javabasico;

public interface Formatador<T> {

	String format(T objeto);
}
