package com.javabasico;

public enum Cor {

	VERMELHO, BRANCO, AZUL, AZUL_BUZIOS, 
	PRETO, AMARELO;
}
