package com.javabasico;

public enum TipoCor {

	SOLIDO, METALICO;
}
