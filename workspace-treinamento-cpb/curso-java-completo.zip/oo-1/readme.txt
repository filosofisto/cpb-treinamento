Programa: 			oo-1
Descricao: 			Primeiro programa OO
Caracteristicas:
  
  1) Demonstra encapsulamento e construtores
  2) Execucao em linha de comando:
  
  		java -jar oo-1-0.0.1-SNAPSHOT.jar