package com.javabasico;

public enum Sexo {

	MASCULINO, FEMININO;
}
