Programa: 			coll-1
Descricao: 			Uso basico de Collection com ArrayList
Caracteristicas:
  
  1) Demonstra utilização de Collection
  2) Execucao em linha de comando:
  
  		java -jar coll-1-0.0.1-SNAPSHOT.jar
