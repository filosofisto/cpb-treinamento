package com.javabasico;

@Quality
public class MyClass {

}
