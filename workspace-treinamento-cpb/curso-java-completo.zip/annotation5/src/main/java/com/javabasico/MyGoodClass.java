package com.javabasico;

import com.javabasico.Quality.Level;

@Quality(value=Level.GOOD)
public class MyGoodClass {

}
