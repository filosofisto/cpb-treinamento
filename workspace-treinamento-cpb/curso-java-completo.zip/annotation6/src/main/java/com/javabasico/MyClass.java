package com.javabasico;

import com.javabasico.Quality.Level;

@Quality(value=Level.BAD)
public class MyClass {

}
