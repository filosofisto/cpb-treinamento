package com.javabasico;

public class MySubClass extends MyClass {

}
