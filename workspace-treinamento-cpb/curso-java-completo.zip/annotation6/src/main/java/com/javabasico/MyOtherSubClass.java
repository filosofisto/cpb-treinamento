package com.javabasico;

import com.javabasico.Quality.Level;

@Quality(Level.GOOD)
public class MyOtherSubClass extends MyClass {

}
