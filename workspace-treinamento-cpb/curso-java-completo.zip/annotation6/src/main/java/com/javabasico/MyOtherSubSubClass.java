package com.javabasico;

public class MyOtherSubSubClass extends MyOtherSubClass {

}
