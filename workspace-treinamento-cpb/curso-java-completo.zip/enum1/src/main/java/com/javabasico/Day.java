package com.javabasico;

public interface Day {
    int SUNDAY = 0; 
    int MONDAY = 1; 
    int TUESDAY = 2; 
    int WEDNESDAY = 3; 
    int THURSDAY = 4; 
    int FRIDAY = 5; 
    int SATURDAY = 6;
}
